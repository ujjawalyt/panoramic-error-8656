package com.human.exception;

public class EmployeeExecption extends Exception {

	
	public EmployeeExecption() {
		// TODO Auto-generated constructor stub
	}
	public EmployeeExecption( String message) {
		super(message);
		
	}
}

