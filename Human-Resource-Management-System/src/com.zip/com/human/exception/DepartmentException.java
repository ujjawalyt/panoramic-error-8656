package com.human.exception;

public class DepartmentException extends Exception{
   
	
	public DepartmentException() {
		// TODO Auto-generated constructor stub
	}
	public DepartmentException(String message) {
	 super(message);
	}
	
}
