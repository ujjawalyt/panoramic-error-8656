package com.human.dao;

public interface AdminDao {

	
	 public String AdminLogin(String username,String password );
}
